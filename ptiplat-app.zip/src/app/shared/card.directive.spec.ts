import { CardDirective } from './card.directive';

describe('CardDirective', () => {
  it('should create an instance', () => {
    const directive = new CardDirective();
    expect(directive).toBeTruthy();
  });
});
